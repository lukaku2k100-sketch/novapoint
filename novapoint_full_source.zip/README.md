# NovaPoint — mã nguồn full-stack

## Tính năng
- Đăng ký/đăng nhập email với Supabase Auth.
- Hồ sơ thành viên, điểm và lịch sử cộng/trừ điểm.
- Nhiệm vụ do Admin tạo; thành viên gửi link minh chứng.
- Admin duyệt/từ chối; điểm được cộng bằng hàm database, không thể tự sửa từ trình duyệt.
- Cửa hàng thẻ game, Liên Quân, Free Fire; gửi đơn đổi.
- Admin duyệt/từ chối; database kiểm tra số dư/tồn kho và trừ điểm khi duyệt.

## Thiết lập backend
1. Tạo project tại https://supabase.com/
2. Mở SQL Editor, chạy toàn bộ `supabase/schema.sql`.
3. Project Settings → API: lấy Project URL và anon/public key.
4. Sao chép `.env.example` thành `.env`, điền `VITE_SUPABASE_URL` và `VITE_SUPABASE_ANON_KEY`.
5. Đăng ký tài khoản NovaPoint đầu tiên. Trong Supabase SQL Editor, cấp quyền admin cho email của bạn:
   `update public.profiles set role='admin' where email='EMAIL_CUA_BAN';`
6. Đăng xuất/đăng nhập lại.

## Chạy local
Cần Node.js LTS:
```bash
npm install
npm run dev
```
Build:
```bash
npm run build
```
## Đưa lên mạng miễn phí
Khuyên dùng Vercel hoặc Netlify (gói miễn phí có thể thay đổi theo chính sách):
- Đẩy source lên GitHub, không tải `.env` lên GitHub.
- Import repo ở https://vercel.com/ hoặc https://www.netlify.com/.
- Build command: `npm run build`; output: `dist`.
- Thêm hai biến môi trường Supabase vào phần Environment Variables.
- Deploy; thêm URL deploy vào Supabase Authentication → URL Configuration → Redirect URLs.

## An toàn
- Không đưa Supabase `service_role` key vào frontend, GitHub hoặc chat. Chỉ dùng anon/public key.
- Không yêu cầu mật khẩu/OTP của Discord, Telegram, Liên Quân, Free Fire.
- Không có giao hàng tự động; Admin xử lý phần thưởng ngoài hệ thống.
- Đây là bộ khởi đầu cần được kiểm thử và rà soát bảo mật trước khi mở công khai. Bổ sung điều khoản, quyền riêng tư, chống spam, giới hạn tần suất, kiểm duyệt link minh chứng và quy trình hỗ trợ.
- Với phần thưởng có giá trị, cần người lớn chịu trách nhiệm và kiểm tra quy định pháp luật/điều khoản nhà phát hành trước khi vận hành.
